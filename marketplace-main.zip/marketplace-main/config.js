export const nftmarketaddress = "0x929548122305728567c854D8E71CB4E7D395662e"
export const nftaddress = "0x44365174a5D6230C10161b4396a11D9ce750ae84"